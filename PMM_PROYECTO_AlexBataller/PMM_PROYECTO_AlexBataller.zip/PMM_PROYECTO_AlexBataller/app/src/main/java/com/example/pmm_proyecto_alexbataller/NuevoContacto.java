package com.example.pmm_proyecto_alexbataller;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

public class NuevoContacto extends AppCompatActivity implements View.OnClickListener {

    private EditText etNombre;
    private EditText etMaterial;
    private EditText etAnyo;
    private Spinner spinnerType;
    private Button btnCrear;
    private Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nuevo_contacto);

        intent =  new Intent(this , RecyclerViewContactos.class);

        etNombre = findViewById(R.id.etNombre);
        etMaterial = findViewById(R.id.etMaterial);
        etAnyo = findViewById(R.id.etAnyo);
        spinnerType = findViewById(R.id.spinnerType);
        btnCrear = findViewById(R.id.btnCrear);

        btnCrear.setOnClickListener(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        Bundle bundleRequest = getIntent().getExtras();
        if(bundleRequest.getInt("requestCode") == RecyclerViewContactos.REQUEST_CODE_EDIT){
            try {
                Contacto r = (Contacto) bundleRequest.getSerializable("contactoEdit");
                etNombre.setText(r.getNombre());
                etMaterial.setText(r.getApellido());
                etAnyo.setText(String.valueOf(r.getAnyo()));
                spinnerType.setSelection(r.getType().ordinal(), true);
                btnCrear.setText(R.string.editar_contacto);


            }catch (NullPointerException e){
                Log.d("NULL", e.toString());
            }
        }
    }

    @Override
    public void onClick(View v) {
        Bundle bundleRequest = getIntent().getExtras();

        ContactType rt;
        switch (spinnerType.getSelectedItem().toString()) {
            case "R2D2":
                rt = ContactType.R2D2;
                break;
            case "BENDER":
                rt = ContactType.BENDER;
                break;
            default:
                rt = ContactType.WALLE;
                break;
        }
        Contacto c;
        try {
            c = new Contacto(rt, etNombre.getText().toString(), etMaterial.getText().toString(), Integer.parseInt(etAnyo.getText().toString()));
        } catch (NumberFormatException e) {
            c = new Contacto(rt, etNombre.getText().toString(), etMaterial.getText().toString(), 2000);
        }

        if (bundleRequest.getInt("requestCode") == RecyclerViewContactos.REQUEST_CODE_NUEVO) {
            Bundle bundle = new Bundle();
            bundle.putSerializable("contactoInser", c);
            intent.putExtras(bundle);
            setResult(RESULT_OK, intent);
            finish();

        }else if(bundleRequest.getInt("requestCode") == RecyclerViewContactos.REQUEST_CODE_EDIT){
            Bundle bundle = new Bundle();
            bundle.putSerializable("contactoEdit", c);
            int contactoPos = bundleRequest.getInt("contactoPos");
            bundle.putInt("contactoPos", contactoPos);
            intent.putExtras(bundle);
            setResult(RESULT_OK, intent);
            finish();
        }
    }
}
