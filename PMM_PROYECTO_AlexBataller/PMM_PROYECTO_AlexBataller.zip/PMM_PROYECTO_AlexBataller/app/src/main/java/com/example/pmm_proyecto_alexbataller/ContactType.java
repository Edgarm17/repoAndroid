package com.example.pmm_proyecto_alexbataller;

public enum ContactType {
    R2D2,
    BENDER,
    WALLE
}
