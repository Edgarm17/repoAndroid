package com.example.pmm_proyecto_alexbataller;


import java.io.Serializable;

public class Contacto implements Serializable {
    private ContactType type;
    private String nombre;
    private String apellido;
    private int anyo;

    public Contacto(ContactType type, String nombre, String apellido, int anyo) {
        this.type = type;
        this.nombre = nombre;
        this.apellido = apellido;
        this.anyo = anyo;
    }

    public ContactType getType() {
        return type;
    }

    public void setType(ContactType type) {
        this.type = type;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public int getAnyo() {
        return anyo;
    }

    public void setAnyo(int anyo) {
        this.anyo = anyo;
    }
}
