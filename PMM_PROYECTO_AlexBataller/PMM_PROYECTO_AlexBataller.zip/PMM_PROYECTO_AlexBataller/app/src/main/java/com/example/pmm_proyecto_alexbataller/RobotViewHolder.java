package com.example.pmm_proyecto_alexbataller;

import android.content.Context;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class RobotViewHolder extends RecyclerView.ViewHolder {

    private ImageView img;
    private TextView tvNombre;
    private TextView tvMaterial;
    private TextView tvAnyo;
    private Context contexto;

    public RobotViewHolder(@NonNull View itemView, Context contexto) {
        super(itemView);
        this.img = itemView.findViewById(R.id.img);
        this.tvNombre = itemView.findViewById(R.id.tvNombre);
        this.tvMaterial = itemView.findViewById(R.id.tvMaterial);
        this.tvAnyo = itemView.findViewById(R.id.tvAnyo);
        this.contexto = contexto;
    }

    public void bindRobot(Contacto r) {
        switch (r.getType()) {
            case R2D2:
                this.img.setImageDrawable(contexto.getDrawable(R.drawable.r2d2));
                break;
            case WALLE:
                this.img.setImageDrawable(contexto.getDrawable(R.drawable.walle));
                break;
            default:
                this.img.setImageDrawable(contexto.getDrawable(R.drawable.bender));
        }

        this.tvNombre.setText(r.getNombre());
        this.tvMaterial.setText(r.getApellido());
        this.tvAnyo.setText(String.valueOf(r.getAnyo()));
    }
}
